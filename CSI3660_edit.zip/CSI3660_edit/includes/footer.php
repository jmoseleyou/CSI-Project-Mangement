<footer>
    <div>
		<p id="footcopy"> Please enjoy your stay on our website </p>
    </div>
    <div>
	 <p class="logoSmall">CSI3660 Project</p>
	 <nav>
        <a href="projectsummary.php" title="View our project summary"> Project Summary </a>
        <a href="ourservice.php" title="Use our service"> Our Service </a>
        <a href="projectbackground.php" title="View our project background"> Project Background </a>
		<a href="projectoverview.php" title="View our project overview"> Project Overview </a>
		<a href="groupmembers.php" title="View our group members"> Group Members</a>
		<a href="screenshots.php" title="View our service in action"> Screenshots </a>
		<a href="references.php" title="View our references"> References </a>
    </nav>
    </div>
    <div>
		<p id="footCopy">Copyright &copy; 2020</p>
    </div>
</footer>