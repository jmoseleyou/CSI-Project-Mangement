<!DOCTYPE html>
<html>
    <head>
        <!-- Webpage Metadata-->
        <meta charset="UTF-8">
		<meta name="author" content="James Moseley, Keith Lattimore, Marcus Dyson">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="A website designed for our 3660 final project.">

        <!-- Webpage Title -->
        <title> CSI 3660 Project </title>

        <!-- Website Icon -->
        <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
		<link rel="manifest" href="images/site.webmanifest">
        
        <!-- Styles -->
		<link href="style.css" media="screen and (min-device-width: 1200px)" rel="stylesheet">
		<style>table {table-layout: fixed;width: 100%;}</style>
		<link href="styleMobile.css" media="screen and (max-width: 1199px)" rel="stylesheet"/>
        
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    </head>
    <body>
        <section id="background"></section>
        
        <!-- Webpage Header -->
        <?php include('includes/header.php'); ?>

        <!-- Main Webpage Content-->
        <main>
			<!-- Parallax Top Image -->
			<div class="parallaxBG-small" style="background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.801), transparent), url('images/pexels-xxss-is-back-777001.jpg'); background-position: right 30%;"></div>
			<div class="parallaxText2" style="left:800px">
				<h1> References </h1>
			</div>
			<div class="standardPad">
			<h2> Here are the sources we used to help build our project: </h2>
				<li> Sources:
						<ul> Place holder </ul>
						<ul> Place holder </ul>
						<ul> Place holder </ul>
						<ul> Place holder </ul>
				</li>
			</div>
        </main>

        <!-- Webpage Footer-->
        <?php include('includes/footer.php'); ?>
    </body>
</html>

